<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Bookmark</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body { background: #f8f9fa; }
        .card { border-radius: 1rem; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border: none; }
        .btn-rounded { border-radius: 50px; }
        h2 { font-weight: 700; color: #333; }
    </style>
</head>
<body>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold">Edit Bookmark</h2>
        <a href="{{ route('bookmarks.index') }}" class="btn btn-secondary btn-rounded">
            <i class="bi bi-arrow-left"></i> Back
        </a>
    </div>

    <div class="card p-4">
        <form action="{{ route('bookmarks.update', $bookmark->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <div class="mb-3">
                <label class="form-label fw-bold">Title</label>
                <input type="text" name="title" class="form-control" value="{{ $bookmark->title }}" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-bold">URL</label>
                <input type="url" name="url" class="form-control" value="{{ $bookmark->url }}" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-bold">Description</label>
                <textarea name="description" class="form-control" rows="3">{{ $bookmark->description }}</textarea>
            </div>

            <div class="mb-3">
                <label class="form-label fw-bold">Current Image</label><br>
                @if($bookmark->image)
                    <img src="{{ asset('storage/'.$bookmark->image) }}" width="150" class="rounded mb-2">
                @else
                    <p class="text-muted">No image uploaded</p>
                @endif
                <input type="file" name="image" class="form-control mt-2">
            </div>

            <button type="submit" class="btn btn-success btn-rounded">
                <i class="bi bi-check-circle"></i> Update Bookmark
            </button>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
