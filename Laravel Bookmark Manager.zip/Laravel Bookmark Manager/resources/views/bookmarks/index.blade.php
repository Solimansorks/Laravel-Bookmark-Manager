<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookmarks</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body { background: #f8f9fa; }
        .card {
            border-radius: 1rem;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.2s;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .btn-rounded { border-radius: 50px; }
        .navbar { border-radius: 0 0 1rem 1rem; }
    </style>
</head>
<body>

<!-- ✅ Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand fw-bold" href="{{ route('bookmarks.index') }}">
        <i class="bi bi-bookmark-star"></i> MyBookmarks
    </a>
    <div>
        <a href="{{ route('bookmarks.create') }}" class="btn btn-light btn-rounded">
            <i class="bi bi-plus-circle"></i> Add Bookmark
        </a>
    </div>
  </div>
</nav>

<div class="container py-5">
    <h2 class="fw-bold mb-4 text-center">All Bookmarks</h2>

    @if($bookmarks->count() > 0)
        <div class="row g-4">
            @foreach($bookmarks as $bookmark)
                <div class="col-md-4">
                    <div class="card h-100">
                        @if($bookmark->image)
                            <img src="{{ asset('storage/'.$bookmark->image) }}" class="card-img-top" alt="{{ $bookmark->title }}">
                        @endif
                        <div class="card-body">
                            <h5 class="card-title">{{ $bookmark->title }}</h5>
                            <p class="card-text text-truncate">{{ $bookmark->description ?? 'No description' }}</p>
                            <a href="{{ $bookmark->url }}" target="_blank" class="btn btn-sm btn-outline-primary btn-rounded mb-2">
                                <i class="bi bi-box-arrow-up-right"></i> Visit
                            </a>
                            <a href="{{ route('bookmarks.show', $bookmark->id) }}" class="btn btn-sm btn-primary btn-rounded mb-2">
                                <i class="bi bi-eye"></i> View
                            </a>
                        </div>
                        <div class="card-footer d-flex justify-content-between">
                            <a href="{{ route('bookmarks.edit', $bookmark->id) }}" class="btn btn-sm btn-warning btn-rounded">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <form action="{{ route('bookmarks.destroy', $bookmark->id) }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <button type="submit" onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger btn-rounded">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    @else
        <div class="alert alert-info text-center">
            No bookmarks added yet. <a href="{{ route('bookmarks.create') }}">Add one now!</a>
        </div>
    @endif
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
