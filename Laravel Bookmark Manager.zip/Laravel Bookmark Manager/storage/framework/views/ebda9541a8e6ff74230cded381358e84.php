<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookmarks</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body { background: #f8f9fa; }
        .card {
            border-radius: 1rem;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: transform 0.2s;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .btn-rounded { border-radius: 50px; }
        .navbar { border-radius: 0 0 1rem 1rem; }
    </style>
</head>
<body>

<!-- ✅ Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand fw-bold" href="<?php echo e(route('bookmarks.index')); ?>">
        <i class="bi bi-bookmark-star"></i> MyBookmarks
    </a>
    <div>
        <a href="<?php echo e(route('bookmarks.create')); ?>" class="btn btn-light btn-rounded">
            <i class="bi bi-plus-circle"></i> Add Bookmark
        </a>
    </div>
  </div>
</nav>

<div class="container py-5">
    <h2 class="fw-bold mb-4 text-center">All Bookmarks</h2>

    <?php if($bookmarks->count() > 0): ?>
        <div class="row g-4">
            <?php $__currentLoopData = $bookmarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookmark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card h-100">
                        <?php if($bookmark->image): ?>
                            <img src="<?php echo e(asset('storage/'.$bookmark->image)); ?>" class="card-img-top" alt="<?php echo e($bookmark->title); ?>">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($bookmark->title); ?></h5>
                            <p class="card-text text-truncate"><?php echo e($bookmark->description ?? 'No description'); ?></p>
                            <a href="<?php echo e($bookmark->url); ?>" target="_blank" class="btn btn-sm btn-outline-primary btn-rounded mb-2">
                                <i class="bi bi-box-arrow-up-right"></i> Visit
                            </a>
                            <a href="<?php echo e(route('bookmarks.show', $bookmark->id)); ?>" class="btn btn-sm btn-primary btn-rounded mb-2">
                                <i class="bi bi-eye"></i> View
                            </a>
                        </div>
                        <div class="card-footer d-flex justify-content-between">
                            <a href="<?php echo e(route('bookmarks.edit', $bookmark->id)); ?>" class="btn btn-sm btn-warning btn-rounded">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <form action="<?php echo e(route('bookmarks.destroy', $bookmark->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger btn-rounded">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="alert alert-info text-center">
            No bookmarks added yet. <a href="<?php echo e(route('bookmarks.create')); ?>">Add one now!</a>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\Paragon\Desktop\Laravel Bookmark Manager\resources\views/bookmarks/index.blade.php ENDPATH**/ ?>