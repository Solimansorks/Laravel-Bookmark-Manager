<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($bookmark->title); ?></title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body { background: #f8f9fa; }
        .card { border-radius: 1rem; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border: none; }
        .btn-rounded { border-radius: 50px; }
        h2 { font-weight: 700; color: #333; }
    </style>
</head>
<body>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold"><?php echo e($bookmark->title); ?></h2>
        <a href="<?php echo e(route('bookmarks.index')); ?>" class="btn btn-secondary btn-rounded">
            <i class="bi bi-arrow-left"></i> Back
        </a>
    </div>

    <div class="card p-4">
        <?php if($bookmark->image): ?>
            <img src="<?php echo e(asset('storage/'.$bookmark->image)); ?>" class="rounded mb-3" width="300">
        <?php endif; ?>

        <p><strong>URL:</strong> <a href="<?php echo e($bookmark->url); ?>" target="_blank"><?php echo e($bookmark->url); ?></a></p>
        <p><strong>Description:</strong> <?php echo e($bookmark->description ?? 'No description provided.'); ?></p>
        <p><strong>Created at:</strong> <?php echo e($bookmark->created_at->format('d M Y - H:i')); ?></p>
        <p><strong>Last updated:</strong> <?php echo e($bookmark->updated_at->format('d M Y - H:i')); ?></p>

        <div class="mt-4">
            <a href="<?php echo e(route('bookmarks.edit', $bookmark->id)); ?>" class="btn btn-warning btn-rounded">
                <i class="bi bi-pencil-square"></i> Edit
            </a>
            <form action="<?php echo e(route('bookmarks.destroy', $bookmark->id)); ?>" method="POST" class="d-inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger btn-rounded" onclick="return confirm('Are you sure?')">
                    <i class="bi bi-trash"></i> Delete
                </button>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\Paragon\Desktop\Laravel Bookmark Manager\resources\views/bookmarks/show.blade.php ENDPATH**/ ?>